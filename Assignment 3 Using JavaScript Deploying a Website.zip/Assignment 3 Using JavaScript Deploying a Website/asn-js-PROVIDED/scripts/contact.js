
const submitButton = document.querySelector('#submit-button'); 
const contactPage = document.querySelector('#contact-page'); 

submitButton.addEventListener('click', function () {

    const thankYouMessage = document.createElement('p');

    thankYouMessage.textContent = 'Thank you for your message';

    thankYouMessage.style.fontSize = '24px';

    contactPage.innerHTML = '';  
    contactPage.appendChild(thankYouMessage);  
});
