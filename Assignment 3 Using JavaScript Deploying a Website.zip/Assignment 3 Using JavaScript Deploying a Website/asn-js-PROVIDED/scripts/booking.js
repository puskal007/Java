let dailyRate = 35; 
let totalCost = 0;
let selectedDays = 0;

const dayButtons = document.querySelectorAll('.day');  
const clearButton = document.querySelector('#clear');  
const calculateButton = document.querySelector('#calculate');  
const calculatedCost = document.querySelector('#calculated-cost');  
const halfDayButton = document.querySelector('#half');  
const fullDayButton = document.querySelector('#full');  

dayButtons.forEach(button => {
    button.addEventListener('click', function () {
        if (!button.classList.contains('clicked')) {
            button.classList.add('clicked');
            selectedDays++;  
        } else {
            button.classList.remove('clicked');
            selectedDays--;  
        }
        recalculateCost(); 
    });
});

clearButton.addEventListener('click', function () {
    dayButtons.forEach(button => {
        button.classList.remove('clicked');
    });
    selectedDays = 0;  
    recalculateCost();  
});

halfDayButton.addEventListener('click', function () {
    if (!halfDayButton.classList.contains('clicked')) {
        dailyRate = 20;  
        halfDayButton.classList.add('clicked');  
        fullDayButton.classList.remove('clicked');  
        recalculateCost();  
    }
});

fullDayButton.addEventListener('click', function () {
    if (!fullDayButton.classList.contains('clicked')) {
        dailyRate = 35;  
        fullDayButton.classList.add('clicked');  
        halfDayButton.classList.remove('clicked');  
        recalculateCost();  
    }
});

calculateButton.addEventListener('click', function () {
    recalculateCost();  
});

function recalculateCost() {
    totalCost = selectedDays * dailyRate;  
    calculatedCost.innerHTML = `$${totalCost.toFixed(2)}`;  
}
